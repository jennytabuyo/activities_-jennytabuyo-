/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class mod01_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         String jj ="the quick brown fox";
        String tt ="queen";
  System.out.println("the given string is: "+jj);
  System.out.println("the given mask string is: "+tt+"\n");
  
 System.out.println("the new string is: "+jj.replace("e","").replace("n", "").replace("qu", ""));
            
    }
    
}
